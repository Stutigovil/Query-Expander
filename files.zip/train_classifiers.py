# ================================================================
#  COLAB SETUP — Run this cell FIRST in Google Colab
# ================================================================
# !pip install transformers datasets scikit-learn pandas torch -q
#
# Upload your dataset_clean.csv:
# from google.colab import files
# files.upload()   ← select dataset_clean.csv
#
# After training, download all 3 folders:
# import shutil
# shutil.make_archive("model_level1",   "zip", "model_level1")
# shutil.make_archive("model_level2",   "zip", "model_level2")
# shutil.make_archive("label_encoders", "zip", "label_encoders")
# files.download("model_level1.zip")
# files.download("model_level2.zip")
# files.download("label_encoders.zip")
# ================================================================

import os, json, pickle, warnings
import numpy as np
import pandas as pd
import torch

from sklearn.model_selection     import train_test_split
from sklearn.preprocessing       import LabelEncoder
from sklearn.metrics             import (accuracy_score, f1_score,
                                         classification_report)
from torch.utils.data            import Dataset
from transformers                import (DistilBertTokenizerFast,
                                         DistilBertForSequenceClassification,
                                         Trainer, TrainingArguments,
                                         EarlyStoppingCallback)
warnings.filterwarnings("ignore")

# ── Hyperparameters ─────────────────────────────────────────
DATASET_PATH   = "dataset_clean.csv"
MODEL_L1_DIR   = "model_level1"
MODEL_L2_DIR   = "model_level2"
ENCODER_DIR    = "label_encoders"
BASE_MODEL     = "distilbert-base-uncased"
MAX_LEN        = 128
BATCH_SIZE     = 16
EPOCHS         = 6
LR             = 2e-5
SEED           = 42
# ────────────────────────────────────────────────────────────

os.makedirs(MODEL_L1_DIR,  exist_ok=True)
os.makedirs(MODEL_L2_DIR,  exist_ok=True)
os.makedirs(ENCODER_DIR,   exist_ok=True)

print("Loading tokenizer...")
tokenizer = DistilBertTokenizerFast.from_pretrained(BASE_MODEL)


# ════════════════════════════════════════════════════════════
#  Dataset wrapper
# ════════════════════════════════════════════════════════════
class TopicDataset(Dataset):
    def __init__(self, texts, labels):
        self.encodings = tokenizer(
            list(texts),
            truncation=True,
            padding="max_length",
            max_length=MAX_LEN
        )
        self.labels = list(labels)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        item = {k: torch.tensor(v[idx])
                for k, v in self.encodings.items()}
        item["labels"] = torch.tensor(self.labels[idx], dtype=torch.long)
        return item


# ════════════════════════════════════════════════════════════
#  Metrics
# ════════════════════════════════════════════════════════════
def compute_metrics(eval_pred):
    logits, labels = eval_pred
    preds = np.argmax(logits, axis=-1)
    return {
        "accuracy" : accuracy_score(labels, preds),
        "f1_macro" : f1_score(labels, preds, average="macro",
                               zero_division=0)
    }


# ════════════════════════════════════════════════════════════
#  Core training function  (reused for L1 and L2)
# ════════════════════════════════════════════════════════════
def train_and_evaluate(texts, raw_labels, output_dir,
                        encoder_path, level_name):

    print(f"\n{'='*60}")
    print(f"  Training {level_name}")
    print(f"{'='*60}")

    # ── Encode labels ──────────────────────────────────────
    le = LabelEncoder()
    encoded = le.fit_transform(raw_labels)
    num_classes = len(le.classes_)
    print(f"Classes ({num_classes}): {list(le.classes_)}")

    with open(encoder_path, "wb") as f:
        pickle.dump(le, f)
    print(f"Encoder saved → {encoder_path}")

    # ── Stratified split  80 / 10 / 10 ────────────────────
    X_tr, X_tmp, y_tr, y_tmp = train_test_split(
        texts, encoded,
        test_size=0.20, random_state=SEED, stratify=encoded
    )
    X_val, X_te, y_val, y_te = train_test_split(
        X_tmp, y_tmp,
        test_size=0.50, random_state=SEED, stratify=y_tmp
    )
    print(f"Train={len(X_tr)}  Val={len(X_val)}  Test={len(X_te)}")

    train_ds = TopicDataset(X_tr,  y_tr)
    val_ds   = TopicDataset(X_val, y_val)
    test_ds  = TopicDataset(X_te,  y_te)

    # ── Model ──────────────────────────────────────────────
    model = DistilBertForSequenceClassification.from_pretrained(
        BASE_MODEL, num_labels=num_classes
    )

    # ── Training args ──────────────────────────────────────
    args = TrainingArguments(
        output_dir=output_dir,
        num_train_epochs=EPOCHS,
        per_device_train_batch_size=BATCH_SIZE,
        per_device_eval_batch_size=BATCH_SIZE,
        learning_rate=LR,
        warmup_ratio=0.1,
        weight_decay=0.01,
        evaluation_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,
        metric_for_best_model="f1_macro",
        greater_is_better=True,
        seed=SEED,
        logging_steps=50,
        report_to="none",           # no wandb
        fp16=torch.cuda.is_available()  # auto mixed precision on GPU
    )

    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        compute_metrics=compute_metrics,
        callbacks=[EarlyStoppingCallback(early_stopping_patience=2)]
    )

    # ── Train ──────────────────────────────────────────────
    trainer.train()

    # ── Evaluate on held-out test set ──────────────────────
    out      = trainer.predict(test_ds)
    preds    = np.argmax(out.predictions, axis=-1)
    y_str    = le.inverse_transform(y_te)
    p_str    = le.inverse_transform(preds)

    acc = accuracy_score(y_te, preds)
    f1  = f1_score(y_te, preds, average="macro", zero_division=0)

    print(f"\n── {level_name} Test Results ──")
    print(f"Accuracy  : {acc:.4f}  ({acc*100:.2f}%)")
    print(f"F1 Macro  : {f1:.4f}")
    print("\nPer-class report:")
    print(classification_report(y_str, p_str, zero_division=0))

    # ── Save model + tokenizer ─────────────────────────────
    trainer.save_model(output_dir)
    tokenizer.save_pretrained(output_dir)
    print(f"Model saved → {output_dir}")

    return le, acc, f1


# ════════════════════════════════════════════════════════════
#  MAIN
# ════════════════════════════════════════════════════════════
if __name__ == "__main__":

    # ── Load & verify dataset ──────────────────────────────
    print(f"Loading {DATASET_PATH} ...")
    df = pd.read_csv(DATASET_PATH)
    df.dropna(subset=["text","label_vertical","label_subdomain"],
              inplace=True)
    df["text"]             = df["text"].astype(str).str.strip()
    df["label_vertical"]   = df["label_vertical"].str.strip()
    df["label_subdomain"]  = df["label_subdomain"].str.strip()

    print(f"\nTotal rows   : {len(df)}")
    print(f"L1 verticals : {df['label_vertical'].nunique()}")
    print(f"L2 subdomains: {df['label_subdomain'].nunique()}")
    print("\nL1 class counts:")
    print(df["label_vertical"].value_counts().to_string())

    texts = df["text"].tolist()

    # ══════════════════════════════════════════════════════
    #  LEVEL 1  —  Vertical classifier  (5 classes)
    #  All rows used, predicts: Politics / Sports /
    #  Technology / Finance / General
    # ══════════════════════════════════════════════════════
    le_l1, acc_l1, f1_l1 = train_and_evaluate(
        texts      = texts,
        raw_labels = df["label_vertical"].tolist(),
        output_dir = MODEL_L1_DIR,
        encoder_path = f"{ENCODER_DIR}/le_level1.pkl",
        level_name = "LEVEL 1 — Vertical Classifier"
    )

    # ══════════════════════════════════════════════════════
    #  LEVEL 2  —  Subdomain classifier  (~44 classes)
    #  Same rows, predicts the fine-grained subdomain.
    #  During inference the app uses the L1 prediction +
    #  taxonomy.json to gate which L2 labels are valid.
    # ══════════════════════════════════════════════════════
    le_l2, acc_l2, f1_l2 = train_and_evaluate(
        texts      = texts,
        raw_labels = df["label_subdomain"].tolist(),
        output_dir = MODEL_L2_DIR,
        encoder_path = f"{ENCODER_DIR}/le_level2.pkl",
        level_name = "LEVEL 2 — Subdomain Classifier"
    )

    # ── Save taxonomy map  L1 → [valid L2 labels] ─────────
    taxonomy = (
        df.groupby("label_vertical")["label_subdomain"]
        .unique()
        .apply(sorted)
        .to_dict()
    )
    with open(f"{ENCODER_DIR}/taxonomy.json", "w") as f:
        json.dump(taxonomy, f, indent=2)
    print(f"\nTaxonomy saved → {ENCODER_DIR}/taxonomy.json")

    # ── Final summary ──────────────────────────────────────
    print("\n" + "="*60)
    print("  TRAINING COMPLETE — SUMMARY")
    print("="*60)
    print(f"  L1 Vertical  accuracy : {acc_l1*100:.2f}%  |  F1: {f1_l1:.4f}")
    print(f"  L2 Subdomain accuracy : {acc_l2*100:.2f}%  |  F1: {f1_l2:.4f}")
    print("="*60)
    print("\nOutputs ready:")
    print(f"  {MODEL_L1_DIR}/       ← Level 1 model + tokenizer")
    print(f"  {MODEL_L2_DIR}/       ← Level 2 model + tokenizer")
    print(f"  {ENCODER_DIR}/        ← le_level1.pkl, le_level2.pkl, taxonomy.json")
    print("\nNext step → copy these 3 folders into your Streamlit project.")
