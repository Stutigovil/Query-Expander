"""
topic_classifier.py
-------------------
Loads the trained L1 + L2 DistilBERT models and exposes a single
function:  predict(text)  → { level1, level2, confidence }

The caller (app.py) passes:
    expanded_user_query + " [SEP] " + bot_answer

Taxonomy gating:
    After L1 predicts a vertical, only the L2 labels that belong to
    that vertical (from taxonomy.json) are considered valid.
    If the raw L2 prediction is outside those labels, we pick the
    highest-scoring valid L2 label from the full softmax distribution.

Confidence threshold:
    If L1 softmax confidence < 0.75  →  fallback to General / Miscellaneous
"""

import os, json, pickle
import numpy as np
import torch
import torch.nn.functional as F
from transformers import (DistilBertTokenizerFast,
                          DistilBertForSequenceClassification)

# ── Paths (relative to project root) ────────────────────────
MODEL_L1_DIR   = "model_level1"
MODEL_L2_DIR   = "model_level2"
ENCODER_DIR    = "label_encoders"
CONFIDENCE_THR = 0.75
MAX_LEN        = 128
DEVICE         = "cuda" if torch.cuda.is_available() else "cpu"


def _load_encoder(path):
    with open(path, "rb") as f:
        return pickle.load(f)


def load_models():
    """
    Returns (tokenizer, model_l1, model_l2, le_l1, le_l2, taxonomy)
    Call this once and cache with @st.cache_resource in app.py
    """
    missing = [d for d in [MODEL_L1_DIR, MODEL_L2_DIR, ENCODER_DIR]
               if not os.path.exists(d)]
    if missing:
        raise FileNotFoundError(
            f"Missing folders: {missing}. "
            "Run train_classifiers.py first."
        )

    print("Loading tokenizer and models...")
    tokenizer = DistilBertTokenizerFast.from_pretrained(MODEL_L1_DIR)

    model_l1 = DistilBertForSequenceClassification.from_pretrained(
        MODEL_L1_DIR).to(DEVICE).eval()
    model_l2 = DistilBertForSequenceClassification.from_pretrained(
        MODEL_L2_DIR).to(DEVICE).eval()

    le_l1 = _load_encoder(f"{ENCODER_DIR}/le_level1.pkl")
    le_l2 = _load_encoder(f"{ENCODER_DIR}/le_level2.pkl")

    with open(f"{ENCODER_DIR}/taxonomy.json") as f:
        taxonomy = json.load(f)

    print("Models loaded ✅")
    return tokenizer, model_l1, model_l2, le_l1, le_l2, taxonomy


def _infer(model, tokenizer, text):
    """Run one forward pass, return (predicted_idx, softmax_probs)."""
    enc = tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        padding="max_length",
        max_length=MAX_LEN
    ).to(DEVICE)

    with torch.no_grad():
        logits = model(**enc).logits          # (1, num_classes)
    probs = F.softmax(logits, dim=-1)[0].cpu().numpy()
    return int(np.argmax(probs)), probs


def predict(text, tokenizer, model_l1, model_l2,
            le_l1, le_l2, taxonomy):
    """
    Parameters
    ----------
    text : str
        expanded_user_query + " [SEP] " + bot_answer

    Returns
    -------
    dict with keys: level1, level2, confidence (float 0-1)
    """
    text = text.strip()

    # ── LEVEL 1 ─────────────────────────────────────────────
    l1_idx, l1_probs = _infer(model_l1, tokenizer, text)
    l1_conf          = float(l1_probs[l1_idx])
    l1_label         = le_l1.inverse_transform([l1_idx])[0]

    # Low confidence → fallback
    if l1_conf < CONFIDENCE_THR:
        return {
            "level1"     : "General",
            "level2"     : "Miscellaneous/General Knowledge",
            "confidence" : l1_conf
        }

    # ── LEVEL 2 ─────────────────────────────────────────────
    l2_idx, l2_probs = _infer(model_l2, tokenizer, text)
    l2_label         = le_l2.inverse_transform([l2_idx])[0]

    # ── Taxonomy gating ─────────────────────────────────────
    valid_subdomains = taxonomy.get(l1_label, [])

    if l2_label not in valid_subdomains and valid_subdomains:
        # Find best valid L2 label from probability distribution
        valid_indices = [
            i for i, cls in enumerate(le_l2.classes_)
            if cls in valid_subdomains
        ]
        if valid_indices:
            best_valid_idx = max(valid_indices,
                                 key=lambda i: l2_probs[i])
            l2_label = le_l2.inverse_transform([best_valid_idx])[0]

    return {
        "level1"     : l1_label,
        "level2"     : l2_label,
        "confidence" : l1_conf
    }
